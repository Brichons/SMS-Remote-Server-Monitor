    <?php

    session_start();
    include_once('db_connect.php');

    $now = new DateTime();
    $count = 0;

//    $page = $_SERVER['PHP_SELF'];
//    $sec = "5";
    ?>

   <!DOCTYPE html>
   <html lang="en">
   <head>
       <meta charset="UTF-8">
<!--       <meta http-equiv="refresh" content="<?php echo $sec ?>; URL='<?php echo $page?>'">-->
       <title></title>
   </head>
   <body>
   
    <?php include_once('navbar.html'); ?>

    <div class="card">
      <h5 class="card-header main-color-bg" style="text-align: center; font-size=20px;">Server Status</h5>
      <div class="card-body">
          <h4 class=" col-sm-11"><i class="fas fa-envelope-square"  id="mail_count" style="float: right"><span><?php echo $count; ?></span></i></h4>
        <table class="table table-striped table-hover" style="width:100%">
          <tr style="text-align:center">
            <th>Notification ID</th>
            <th>Server ID</th>
            <th>Domain Name</th>
            <th>IP Address</th>
            <th>Assigned To</th>
            <th>Report Time</th>
            <th>Server Status</th>
            <th>Maintainance Report</th>
          </tr>
    <?php

    $sql = "SELECT * FROM notification";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while($row = $result->fetch_assoc()) {
            foreach($result as $msg) 
            {
                if($msg['serverstatus'] === '1')
                {
                    echo 
                        "<tr style='text-align:center'>
                        <td>#".$msg['notificationid'].
                        "</td><td>SVR 0"  .$msg['serverid']. 
                        "</td><td>" .$msg['domainname']. 
                        "</td><td>" .$msg['ipaddress'].
                        "</td><td>" .$msg['assigned_user'].
                        "</td><td>" .$now->format('d-m-Y H:i:s').
                        "</td><td><img src='images/server_on.png' width='20' height='20'>
                        </td><td style='color: green'>Online...</td></tr>";
                }
                else
                {
                    echo 
                        "<tr style='text-align:center'>
                        <td>#".$msg['notificationid'].
                        "</td><td>SVR 0"  .$msg['serverid']. 
                        "</td><td>" .$msg['domainname']. 
                        "</td><td>" .$msg['ipaddress'].
                        "</td><td>" .$msg['assigned_user'].
                        "</td><td>" .$now->format('d-m-Y H:i:s').
                        "</td><td><img src='images/server_off.png' width='20' height='20'>
                        </td><td style='color: red'>Server down!</td> </tr>";
                    ++$count;
                } 

            }

        }
        echo "</tbody></table></div></div>";
    } else {
        echo "<p style='color: red'>No active servers.";
    }
    $conn->close();

    ?>

    <script>
        function loadDoc() {
            
            setInterval(function() {
                var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                     document.getElementById("mail_count").innerHTML = this.responseText;
                    }
                  };
                  xhttp.open("GET", "notification_processor.php", true);
                  xhttp.send();
            }, 1000);
        }
        loadDoc();
        
        //Code to lock the browser's back button
        $(document).ready(function() {
           function disablePrev() {window.history.forward() } 
           window.onload = disablePrev();
           window.onpageshow = function(evt) { if(evt.persisted) disableBack()}
        });
    </script>

