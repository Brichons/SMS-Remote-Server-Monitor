<?php

include_once('db_connect.php');

$sql = "SELECT * FROM notification WHERE serverstatus = '0'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);
        $count = mysqli_num_rows($result);
        
        echo " $count";

$conn->close();

?>