-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2020 at 10:17 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms_rsms`
--

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `notificationid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(10) NOT NULL,
  `assigned_user` varchar(255) NOT NULL,
  `serverid` int(11) NOT NULL,
  `domainname` varchar(20) NOT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `datetime` date NOT NULL,
  `serverstatus` varchar(15) DEFAULT NULL,
  `complete_datetime` date DEFAULT NULL,
  PRIMARY KEY (`notificationid`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
CREATE TABLE IF NOT EXISTS `server` (
  `serverid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(10) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `domainname` varchar(30) NOT NULL,
  `ipaddress` varchar(20) NOT NULL,
  `serverstatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`serverid`)
) ENGINE=MyISAM AUTO_INCREMENT=4449 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userid` varchar(10) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenumber` int(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `userstatus` int(1) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `usertype`, `firstname`, `lastname`, `email`, `phonenumber`, `password`, `userstatus`) VALUES
('s23', 'Admin', 'Bright', 'Chongo', 'brichonsgraphix@gmail.com', 966230684, 'c6ad0c4fd2ecf1c208341f364e965709', 0),
('s11', 'Admin', 'Emmanuel', 'Mbewe', 'embewe08@gmail.com', 966258796, 'e046cf5be5053667cba83298bc5080fa', 0),
('s24', 'Standard User', 'Diana', 'Nayame', 'sms.remoteserversystem@gmail.com', 977318411, '518d5f3401534f5c6c21977f12f60989', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
