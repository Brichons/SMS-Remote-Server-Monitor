<?php
    
    session_start();
    require_once('db_connect.php');

    $page = $_SERVER['PHP_SELF'];
    $sec = "5";
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="<?php echo $sec ?>; URL='<?php echo $page?>'">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style_template.css">
    
    <title></title>
</head>
<body>

<?php include_once('navbar.html'); ?>

<div class="container">
    <header>
        <h1>User Status</h1>    
    </header>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">User ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email Address</th>
      <th scope="col">Phone Number</th>
      <th scope="col">User Status</th>
    </tr>
  </thead> 
    <tbody>
    <?php
    
        $sql = "SELECT * FROM users WHERE userstatus = '1'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
            while($row = $result->fetch_assoc()) {
                if($_SESSION['username'] != $row['firstname']) {
                    echo "<tr><td>" .$row['userid']. 
                        "</td><td>" .$row['firstname']. 
                        "</td><td>" .$row['lastname'].
                        "</td><td>" .$row['email'].
                        "</td><td>0" .$row['phonenumber']. 
                        "</td><td id='online' style='color: green'>Online</td><tr>";
                } 
            }
            echo "</tbody></table>";
        }
//        else {
//            echo "<p style='color: red'>No logged in users.";
//        } 
        $conn->close();
        
    ?>
    
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
    //Code to lock the browser's back button
    $(document).ready(function() {
       function disablePrev() {window.history.forward() } 
       window.onload = disablePrev();
       window.onpageshow = function(evt) { if(evt.persisted) disableBack()}
    });
</script>

</body>
</html>