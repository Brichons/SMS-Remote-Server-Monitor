<?php
    session_start();
    require_once('db_connect.php');
    if(!isset($_SESSION['userid'])) {
        header("Location: index.php");
    }

    if(isset($_GET['logout'])) {
        session_destroy();
//        unset($_SESSION);
        header("Location: index.php");
    }
    $page = $_SERVER['PHP_SELF'];
    $sec = "5";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="<?php echo $sec ?>; URL='<?php echo $page?>'">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style_template.css">
    <title></title>
</head>
<body>


<!-- Nav Bar-->
  <?php include_once('navbar.html'); ?>

<div class="container">
    <header>
        <h1>Server Status</h1>    
    </header>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Server Status</th>
      <th scope="col">Server ID</th>
      <th scope="col">Domain Name</th>
      <th scope="col">IP Address</th>
      <th scope="col">Assigned User</th>
    </tr>
  </thead>
  <tbody>
    <?php
    
        $sql = "SELECT * FROM server";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
            while($row = $result->fetch_assoc()) {
                foreach($result as $server) 
                {
                    if($server['serverstatus'] === '1')
                    {
                        echo "<tr><td><img src='images/server_on.png' width='20' height='20'></td><td>SVR 0" .$server['serverid']. 
                    "</td><td>" .$server['domainname']. 
                    "</td><td>" .$server['ipaddress']. 
                    "</td><td>" .$server['username']. 
                    "</td></tr>";
                    }
                    else
                    {
                        echo "<tr><td><img src='images/server_off.png' width='20' height='20'></td><td>SVR 0" .$server['serverid']. 
                    "</td><td>" .$server['domainname']. 
                    "</td><td>" .$server['ipaddress']. 
                    "</td><td>" .$server['username']. 
                    "</td></tr>";
                    }
//                    echo "";
                }
                
            }
            echo "</tbody></table>";
        } else {
            echo "<p style='color: red'>No active servers.";
        }
        $conn->close();
        
    ?>
    
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
    //Code to lock the browser's back button
        $(document).ready(function() {
           function disablePrev() {window.history.forward() } 
           window.onload = disablePrev();
           window.onpageshow = function(evt) { if(evt.persisted) disableBack()}
        });
</script>

</body>
</html>