<?php
session_start();
include('db_connect.php');

if(!empty($_POST['update'])) {
    $serverid = $_POST['update'];
    
    $now = new DateTime();
    $mail_count = 0;
    
 $sql = "SELECT * FROM server";
        $result = mysqli_query($conn, $sql);
        $serverCount = mysqli_num_rows($result);
        $count = 0;
        if($serverCount > 0) {
            if($row = $result->fetch_assoc()) {
                
                foreach($serverid as $key => $serverID) { 
                    if($row['serverstatus'] == 0){
                        $query = "UPDATE server SET serverstatus = '1' WHERE serverid = '$serverID'";
                        $onResult = mysqli_query($conn, $query);
                        if($onResult) {
//                            echo $serverID.": ON! ";
                        } 
                                    
                        $query = "UPDATE `notification` SET serverstatus = '1' WHERE serverid = '$serverID'";
                            $backOnline = mysqli_query($conn, $query);
                            if($backOnline) {
                                echo "Server: $serverID is back Online.<br/>";
                            } 
                                    
                    }else {
                        $query = "UPDATE server SET serverstatus = '0' WHERE serverid = '$serverID'";
                        $onResult = mysqli_query($conn, $query);
                        if($onResult) {
                            $sql = "SELECT * FROM server WHERE serverid = '".$serverID."'";
                            $result = mysqli_query($conn, $sql);
                            if (mysqli_num_rows($result) > 0) {
                                $userRow = $result->fetch_assoc();
                                
                                $userid = $userRow['userid'];
                                $username = $userRow['username'];
                                $domainname = $userRow['domainname'];
                                $ipaddress = $userRow['ipaddress'];
                                $serverstatus = 1;
                                $date = $now->format('Y-m-d H:i:s');
                            
                                echo "Server: $serverID is <span style='color:red'> Offline!</span> ";
                                //send email to responsible engineer
                                $to = $userRow['email'];
                                $subject = "SERVER: ".$serverID." DOWN at exactly ".$now->format('d-m-Y H:i');
                                $message = "Hello ".$userRow['username'].",\nServer: ".$serverID." has gone offline. Kindly check it and respond ASAP.\nUpdate server status on this link when done: http://localhost/sms_rsms/system_switch.php";
                                $headers = "From: sms.remoteserversystem@gmail.com";

                                if(mail($to, $subject, $message, $headers)) {
                                    echo "Mail successfully sent to $username.<br/>";
                                    
                                    //Update notification table with faulty server
                                    $mail_count = 1;
                                    $serverstatus = 0;
                                    
                                    if($mail_count == 1) {
                                        
                                        //insert data into a notification table
                                        $sqlInsert = "INSERT INTO `notification`
                                            (`userid`,
                                            `assigned_user`,
                                            `serverid`,
                                            `domainname`,
                                            `ipaddress`,
                                            `datetime`,
                                            `serverstatus`, 
                                            `complete_datetime`) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                            $stmt = $conn->prepare($sqlInsert);
                                            $stmt->bind_param("ssisssss",  
                                                              $userid,
                                                              $username,
                                                              $serverID,
                                                              $domainname,
                                                              $ipaddress,
                                                              $date,
                                                              $serverstatus,
                                                              $complete_datetime);

                                        if ($stmt->execute()) {
                                            #echo "Notification Updated.";
                                        } 
                                } else {
                                    
                                    
                                    }
                                    
                                }
                            } else {
                                echo "Email not selected.";
                            }
                        }
                    }
                }
            } 
        }

}

?>